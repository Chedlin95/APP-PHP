<?php
 require_once('stock.php');
 $code_stock ="";
 $quantite = "";
 $produit_code ="";

 
if(isset($_GET['code_stock'])){

    $code_stock= $_GET['code_stock'];
    $con= connect();
    $sql ="SELECT * FROM stock WHERE code_stock='$code_stock'";
    $result =$con->query($sql);
    $req = $result->fetchAll();

    foreach($req as $s){
        $code_stock = $s['code_stock']; 
        $quantite = $s['Qte'];
        $produit_code = $s['produit_code'];
    
    }

}


?>

<?php
          
         

          if(isset($_POST['Update_Stock']))
          {
             
            $p = new stock();
          
            $p->setCodeStock($_POST['code_stock']);
            $p->setQuantite($_POST['Qte']);
            $p->setProduitCode($_POST['produit_code']);
           
            

                  if( 
                    $p->Update_Stock(
                    $p->getCodeStock(),
                    $p->getQuantite(),
                    $p->getProduitCode()
                

                  ))

                  {
                  echo('                         
                              <span style= "background-color:blue " class="alert alert-success col-sm-4" role="alert">
                                  Modification avec succes!
                              </span>
                      ');
                  }
            }
    ?>

<br><br><br>


<form action="" method="POST">
     <center><h4 style="text-shadow:1px 2px 1px blue;color:#383f39;margin-top:-20px;text-aligne:center;">Modification de Stock</h4></center>
    
     <div class="form-group">
        <label for="exampleFormControlInput1">code stock</label>
        <input type="text" readonly="true" value="<?php if(isset($code_stock)){echo($code_stock);} ?>" name="code_stock" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>


    <div class="form-group">
        <label for="exampleFormControlInput1"> produit code</label>
        <input type="text" readonly="true" value="<?php if(isset($produit_code)){echo($produit_code);} ?>" name="produit_code" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    
    
    <div class="form-group">
        <label for="exampleFormControlInput1">Quantité</label>
        <input type="text" value="<?php if(isset($quantite)){echo($quantite);} ?>" name="Qte" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
   
    <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Valider" name="Update_Stock">
        <!-- <button style="color:white;border:none;width:300px;float:right;margin-right:20px;top:-10px;background:#4c4c4c;" type="reset" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Go to check for Update</button>
        <button style="color:white;border:none;width:150px;float:right;margin-right:20px;top:-10px;background:green;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i> View satistics</button>
        <button style="color:white;border:none;width:150px;float:left;margin-right:20px;top:-10px;background:green;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-paper-plane" aria-hidden="true"></i> Enregistrer</button> -->
        <?php if(isset($v1)){echo('<button style="color:white;border:none;width:200px;float:left;margin-right:20px;top:-10px;background:#d1931b;" type="submit" name="update_produit" class="btn btn-warning"><i class="fa fa-paper-plane" aria-hidden="true"></i> Update Succesfuly</button>');}?>
    </div>  

    

</form>

<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item active">
      <a class="page-link" href="?listerStock" tabindex="-1">Previous</a>
    <!-- </li>
    <li class="page-item"><a class="page-link" href="?gestion_vente"> <span class="sr-only">(current)</span>Gestion de vente</a></li>
     -->
  </ul>
</nav>