<?php
include('connexion.php');

class ProduitType
{
    private $Type_produit;
    private $type_name;

    public function getType()
    {
        return $this->Type_produit;
    }

    public function setType($newType)
    {
        $this->Type_produit=$newType;
    }

    public function getTypeName()
    {
        return $this->type_name;
    
    }

    public function setTypeName($newName)
    {
        $this->type_name=$newName;
    }

    // Insertion des produits_type 
    public function  Insert($Type_produit,$type_name)
    {
        try{
            $conn = connect();
            $p = $conn->prepare("CALL InsertProduitType (:t, :n)");
            $p->bindParam(':t', $Type_produit);
            $p->bindParam('n',$type_name);
 
            $response =$p->execute();
            return $response;
        
        }catch(PDOExeception $e)
        {
            echo $e->getMessage();
        }
    
    }
     // Update des produits_type 
     public function  Update_produit_type($Type_produit,$type_name)
     {
         try{
             $conn = connect();
             $p = $conn->prepare("CALL Update_produit_type (:t, :n)");
             $p->bindParam(':t', $Type_produit);
             $p->bindParam('n',$type_name);
  
             $response =$p->execute();
             return $response;
         
         }catch(PDOExeception $e)
         {
             echo $e->getMessage();
         }
     
     }

     // Delete type de produit 
    public function  DeleteProduitType($Type_produit)
    {
        try{
            $conn = connect();
            $p = $conn->prepare("CALL Delete_type_produit (:t)");
            $p->bindParam(':t', $Type_produit);
            
            $response =$p->execute();
            return $response;
        
        }catch(PDOExeception $e)
        {
            echo $e->getMessage();
        }
    
    }

}


// $pro = new ProduitType();
// $Type_produit = readline("Entrer le type de produit: ");
// $pro->setType($Type_produit);

// $type_name = readline("Entrer le type nom du produit: ");
// $pro->setTypeName($type_name);

// $pro->UpdateProduitType($Type_produit,$type_name,);

// if ($pro);
// echo "Insertion reussie" ;


// delete




// $pro = new ProduitType();
// $Type_produit = readline("Entrer le type de produit: ");
// $pro->setType($Type_produit);

// $pro->DeleteProduitType($Type_produit);

// if ($pro);
// echo "Suppression reussie" ;

?>