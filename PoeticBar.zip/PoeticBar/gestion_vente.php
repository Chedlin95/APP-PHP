<?php
include("connection_DB.php");

$sql="SELECT * FROM vente_produit";
$exec = $con->query($sql);
$tous =$exec->fetchAll();

?>
<div style="color:blue; font-size:28px; text-align:center">Gestion des ventes</div>
<br>


<table class="table">
  <thead>
    <tr>
      <th scope="col">Code vente</th>
      <th scope="col">code produit</th>
      <th scope="col">Quantite</th>
      <th scope="col">Total</th>
      <th scope="col">Date</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($tous as $v){
        echo("
            <tr>
                <td>$v[Code_vente]</td>
                <td>$v[produit_code]</td>
                <td>$v[Qte]</td>
                <td>$v[Total]</td>
                <td>$v[Date_vente]</td>
                <td><a href='?Code_vente=$v[Code_vente]'>Modifier</a></td>
                <td><a href='?Code_vente=$v[Code_vente]' style='color:red;'>Suprimer</a></td>
            </tr>
        ");
    }

    ?>
  </tbody>
</table>


<?php

  include("connection_DB.php");
  if(isset($_GET['rapport_journalier'])){
    $Aujourdhuit = $_GET['Aujourdhuit'];
    $sql="SELECT vente_produit.code_vente, produit.produit_code,produit.produit_name,vente_produit.qte,vente_produit.total,vente_produit.date_vente FROM produit INNER JOIN vente_produit WHERE produit.produit_code=vente_produit.produit_code AND vente_produit.date_vente='$Aujourdhuit'";
    $execution = $con->query($sql);
    $data_date = $execution->fetchAll();
  }
 

?>


<?php

     if(isset($_GET['date1']) AND isset($_GET['date2'])){
       $date1 = $_GET['date1'];
       $date2 = $_GET['date2'];
      
      $sql="SELECT vente_produit.code_vente, produit.produit_code,produit.produit_name,vente_produit.qte,vente_produit.total,vente_produit.date_vente FROM produit INNER JOIN vente_produit WHERE produit.produit_code=vente_produit.produit_code AND vente_produit.date_vente BETWEEN '$date1' AND '$date2'";
      $execution = $con->query($sql);
      $data1 = $execution->fetchAll();
    }
   


?>
<div style="margin-right:200px;">
<form class="form-inline" method="GET">
  
  <div class="form-group mx-sm-3">

    <input type="date" required name="Aujourdhuit" class="form-control" id="inputPassword2" placeholder="Password">
  </div>
  <button type="submit" name="rapport_journalier" class="btn btn-primary"><i class='fa fa-clock' aria-hidden='true'></i> Recherche a ppartir d'une date</button>
</form>
</div><br>


<div style="margin-right:200px;">
<form class="form-inline" method="GET">
  
  <div class="form-group mx-sm-3">
    <input type="date" required name="date1" class="form-control" id="inputPassword2" placeholder="Password">
  </div>

  <div class="form-group mx-sm-3">
    <input type="date" required name="date2" class="form-control" id="inputPassword2" placeholder="Password">
  </div>
  <button type="submit" name="rapport_deux_date" class="btn btn-primary"><i class='fa fa-clock' aria-hidden='true'></i> Recherche Entrez Deux dates</button>
</form>
</div><br>
<div class="card" style="border:3px solid #5c5a57;margin-right:-20px; float:right;width:1100px;box-shadow:1px 1px 5px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
    <tr style="background:#5c5a57;color:blue">
      <th style="color:white;font-weight:bolder;" scope="col">code vente</th>
      <th style="color:white;font-weight:bolder;"scope="col">produit name</th>
      <th style="color:white;font-weight:bolder;"scope="col"> produit code</th>
      <th style="color:white;font-weight:bolder;"scope="col">Date</th>
      <th style="color:white;font-weight:bolder;"scope="col">Quantite vendues</th>
      <th style="color:white;font-weight:bolder;"scope="col">Montant Total</th>
    </tr>
  </thead>
  <tbody>
  <?php
  if(isset($data_date)){
    foreach($data_date as $rs){
      echo("
          <tr>
              <td>$rs[code_vente]</td>
              <td>$rs[produit_name]</td>
              <td>$rs[produit_code]</td>
              <td>$rs[date_vente]</td>
              <td>$rs[qte]</td>
              <td>$rs[total]</td>
          </tr>
      ");
    }}
     
    ?>

<?php
if(isset($data1)){
    foreach($data1 as $rss){
      echo("
          <tr>
              <td>$rss[code_vente]</td>
              <td>$rss[produit_name]</td>
              <td>$rss[produit_code]</td>
              <td>$rss[date_vente]</td>
              <td>$rss[qte]</td>
              <td>$rss[total]</td>
          </tr>
      ");
    }
    }
     
    ?>
  </tbody>
</table>

  </div>
</div>


<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item active">
      <a class="page-link" href="?frmVente" tabindex="-1">Previous</a>

</nav>