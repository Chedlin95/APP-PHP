<?php 
 include('connexion.php');

class produits
{
    private $produit_code;
    private $produit_name;
    private $Type_produit;
    

    public function __construct()
    {

    }
        
    public function getCode()
    {
        return $this ->produit_code;
    } 

    public function setCode($newCode)
    {
         $this->produit_code = $newCode;
    }


    public function getProduitName()
    {
        return $this->produit_name;
    }

    public function setProduitName($newName)
    {
        $this->produit_name = $newName;
    }

    public function getType()
    {
        return $this->Type_produit;
    }

    public function SetType($newType)
    {
        $this->Type_produit =$newType;
    }



    // Insertion des produits 
    public function InsertProduit($produit_code,$produit_name,$Type_produit)
    {
            try{
            $conn = connect();
            $p = $conn->prepare("CALL InsertProduit(:c, :n, :t)");

            $p->bindParam(':c',$produit_code);
            $p->bindParam(':n',$produit_name);
            $p->bindParam(':t',$Type_produit);

            $response = $p->execute();

            return $response;
            
              }
                 catch(PDOException $e)
                 {

                    echo $e->getMessage();

                 }
    }


    //Selection de produit
    public function Select()
    {
         try{
            $sql="CALL 	SelectProduit()";
            $conn = connect();
            $p=$conn->prepare($sql);
            $p->execute();
            $result = $p->fetchAll(PDO::FETCH_ASSOC);
    
            return $result;
            }
            catch(PDOException $e)
            {
                echo $e->getMessage();
            }
    }
    //Update produit
      
     public function Update_Produit($produit_code,$produit_name,$Type_produit)
     {
             try{
             $conn = connect();
             $p = $conn->prepare("CALL 	Update_Produit(:c, :n, :t)");
 
             $p->bindParam(':c',$produit_code);
             $p->bindParam(':n',$produit_name);
             $p->bindParam(':t',$Type_produit);
 
             $response = $p->execute();
 
             return $response;
             
               }
                  catch(PDOException $e)
                  {
 
                     echo $e->getMessage();
 
                  }
                
     }

     public function DeleteProduit($produit_code)
    {
            try{
            $conn = connect();
            $p = $conn->prepare("CALL Delete_Produit(:c)");

            $p->bindParam(':c',$produit_code);
            

            $response = $p->execute();

            return $response;
            
              }
                 catch(PDOException $e)
                 {

                    echo $e->getMessage();

                 }
    }

}


// $p = new produits();
// $produit_code = readline("Entrer le code du produit: ");
// $p->setCode($produit_code);
// $produit_name = readline("Entrer name: ");
// $p->setProduitName($produit_name);
// $Type_produit = readline("Entrer type: ");
// $p->getType($Type_produit);


// $p->Update_Produit($produit_code,$produit_name,$Type_produit);

// if ($p);
// echo "modification reussie" ;

?>

