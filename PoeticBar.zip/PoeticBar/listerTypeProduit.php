<?php
include("connexion.php");

$con =connect();
$sql="SELECT * FROM produit_type";
$exec = $con->query($sql);
$tous =$exec->fetchAll();

?>
<div style="color:blue; font-size:28px; text-align:center">Liste des Types de Produit</div>
<br>


<table class="table">
  <thead>
    <tr>
      <th scope="col">Type Produit</th>
      <th scope="col">Type Name</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($tous as $p){
        echo("
            <tr>
                <td>$p[type_produit]</td>
                <td>$p[type_name]</td>
                
                
                <td><a href='?type_produit=$p[type_produit]'>Modifier</a></td>
                <td><a href='?type_produit=$p[type_produit]' style='color:red;'>Suprimer</a></td>
            </tr>
        ");
    }

    ?>
  </tbody>
</table>

<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item active">
      <a class="page-link" href="?frmProduit_type" tabindex="-1">Previous</a>

</nav>