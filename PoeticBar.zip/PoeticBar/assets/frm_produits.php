
<?php
session_start();

?>

<!doctype html>
<html lang="pt-br">
<head>

    <meta charset="utf-8"/>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title>PoeticBar</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>

    <!-- Bootstrap core CSS     -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Animation library for notifications   -->
    <link href="css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="css/demo.css" rel="stylesheet"/>

    <link href="css/style.css" rel="stylesheet">


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="css/pe-icon-7-stroke.css" rel="stylesheet"/>

</head>
<body>
   

<div id="recherche">

                    <form action="" method="GET">
                    <table>
                        <tr>
                            <td>Rechercher une Personne </td>
                                <td>
                                <input type="Search" name="rech" >
                            </td>
                          <td>
                                 <input type="submit" class="btn btn-primary" value="RechercheR" name="recherche">
                            </td>
                         </tr>
                        </table>
                    </form>
                          
</div>
                       



<br>
<!-- 

                            <table width="100%" border="1px" class="w3-table-all w3-striped w3-border">
<tr style =" background-color:gray; color:rgb(16, 55, 58)" >
  <th>Code</th>
  <th>Nom</th>
  <th>Prenom</th>
  <th>Sexe</th>
  <th>Nationalite</th>
  <th>Date Naissance</th>
  <th>Téléphone</th>
  <th>Email</th>
  <th>Type Personne</th>
</tr>
<tr class="w3-hover-red">

<?php
                        if(isset($_GET['recherche'])){
                        $recherche = (int)$_GET['rech'];
                        echo("<tr>");
                        echo('<td>'.$_SESSION['personne'][$recherche]['code'].'</td>');                     
                        echo('<td>'.$_SESSION['personne'][$recherche]['nom'].'</td>');                
                        echo('<td>'.$_SESSION['personne'][$recherche]['prenom'].'</td>');               
                        echo('<td>'.$_SESSION['personne'][$recherche]['sexe'].'</td>');
                        echo('<td>'.$_SESSION['personne'][$recherche]['nationalite'].'</td>');                
                        echo('<td>'.$_SESSION['personne'][$recherche]['date_nais'].'</td>');
                        echo('<td>'.$_SESSION['personne'][$recherche]['tel'].'</td>');
                        echo('<td>'.$_SESSION['personne'][$recherche]['email'].'</td>');
                        echo('<td>'.$_SESSION['personne'][$recherche]['type'].'</td>');
                        echo("</tr>");
                        
                    //getCode($recherche);
                        
                    }
                        
                ?> 

       
</tr>
</table>





                <br>
               

        <div id="formulaire">
        <form action="Formulaire.php" method="post">

                            <div class="row" style="border:1px solid cadetblue ;height:auto;width:1055px;margin-left:50px;box-shadow:3px 3px 3px #becabe;box-shadow:inset 3px 3px 3px #becabe;">
                            <div class="col" style="width:10px">
                            <br>

                            <?php
                require("Personne.php");
      
                $tab_Personne[]= null;

                if(isset($_POST['valider'])){
                {
                    $code = $_POST['code'];
                    $nom = $_POST['nom'];
                    $prenom = $_POST['prenom'];
                    $sexe = $_POST['sexe'];
                    $nationalite = $_POST['nationalite'];
                    $date_nais = $_POST['date_nais'];
                    $tel = $_POST['tel'];
                    $email = $_POST['email'];
                    $type = $_POST['type'];

                    $p = new Personne($code, $nom, $prenom, $sexe,$nationalite, $date_nais, $tel,$email, $type);

                    $t_personne = [
                        'code'=> $p->getcode(),
                        'nom'=> $p->getnom(),
                        'prenom' => $p->getprenom(),
                        'sexe'=> $p->getsexe(),
                        'nationalite'=> $p->getnationalite(),
                        'date_nais'=> $p->getdate_nais(),
                        'tel'=> $p->gettel(),
                        'email'=> $p->getemail(),
                        'type'=> $p->gettype()
                    ];
              
                    $_SESSION['personne'][]=$t_personne;


                    echo("<div class='alert alert-success' role='aler'><pre style='color:rgb(16, 55, 58);font-size:18px;text-align:center;font-weight:bolder;'><i class='fa fa-hand-point-right' style='font-size:20px;margin-top:2px;color:rgb(16, 55, 58);'></i> Enregistrement de <b style='color:red;'>$nom</b>  <b style='color:red;'>$prenom</b> dans le tableau <i class='fa fa-database' style='font-size:20px;margin-top:2px;color: rgb(16, 55, 58);'></i></pre><form method='post'><input type='submit' value='OK' style='color:white;background:cadetblue;font-weight:bolder;'></form></div>");
                  
                }
                }


                $cher = array_search(1,$_SESSION['personne']);
              echo("<pre>");
                 print_r($cher);
                 
             echo("</pre>");


            ?> -->

      <br>
                            <p style="font-size: 28px; color: rgb(16, 55, 58) ; text-align :center;">Formulaire d'enregistrement des Personnes</p>
                            <br>
                            <label for="Nom_patient"class="label_patient"style="color: cadetblue;font-weight:bolder;">Code</label>
                            <input type="text" class="form-control " placeholder="" name="code" id="code" value="" style=" cadetblue">
                            <label for="Nom_patient"class="label_patient"style="color: cadetblue;font-weight:bolder;">Nom</label>
                            <input type="text" class="form-control " placeholder="" name="nom" id="nom" value="" style="  cadetblue">
                            <label for="Prenom_patient" class="label_patient"style="color: cadetblue;font-weight:bolder;">Prénom </label>
                            <input type="text" class="form-control" placeholder="" name="prenom" id="prenom"  value="" style=" cadetblue" >
                            <label for="Sexe" class="label_patient"style="color: cadetblue;font-weight:bolder;">Sexe</label>
                            <select  class="custom-select d-block my-3" style=" cadetblue;" class="form-control is-valid" name="sexe" value="" >
                                <option value="Femme">F</option>
                                <option value="Homme" >M</option>
                            </select>
                            <label for="Prenom_patient" class="label_patient"style="color: cadetblue;font-weight:bolder;">Nationalite </label>
                            <input type="text" class="form-control" placeholder="" name="nationalite" id="nationalite"  value="" style="color:green;" >
                            <label for="Date"class="label_patient"style="color: cadetblue;font-weight:bolder;">Date de naissance</label>
                            <input type="date" class="form-control " placeholder="" name="date_nais" id="date_nais"  value="" style="color: black;" >
                            <label for="Prenom_patient" class="label_patient"style="color: cadetblue;font-weight:bolder;">Telephone </label>
                            <input type="text" class="form-control" placeholder="" name="tel" id="tel"  value="" style="color:green;" >
                            <label for="Prenom_patient" class="label_patient"style="color: cadetblue;font-weight:bolder;">Email</label>
                            <input type="text" class="form-control" placeholder="" name="email" id="email"  value="" style="color:green;" >
                            <label for="Prenom_patient" class="label_patient"style="color: cadetblue;font-weight:bolder;">Type Personne</label>
                            <select required class="custom-select d-block my-3" style="color: cadetblue;" class="form-control is-valid" name="type" value="" >
                                <option value="Etudiant">Etudiants</option>
                                <option value="Professeur" >Professeur</option>
                                <option value="Pesonnelle administrative" >Personnelle administrative</option>
                            </select>
         
             <br>
                            <input type="submit" class="btn btn-primary" value="Enregistrer" name="valider">
                          
          <br>
        </form>
        </div>  
         

</div>
</div>

<br>
<footer> 
<br><p> 29, 2eme RUELLE NAZON, PORT-AU-PRINCE <br>
                 TEL:+ (509) 2226-4789 / 3778-6922 <br>
                           WWW.ESIH.EDU
</p>
</footer>   
</body>
</html>