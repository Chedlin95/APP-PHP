<?php
include("connexion.php");

class stock
{    private $code_stock;
     private $quantite;
     private $produit_code;



     

     public function getCodeStock()
     {
         return $this->code_stock;
     }
 
     public function setCodeStock($code_stock)
     {
         $this->code_stock =$code_stock;
     }

     public function getQuantite()
     {
         return $this->quantite;
     }
 
     public function setQuantite($quantite)
     {
         $this->quantite=$quantite;
     }

    public function getProduitCode()
    {
        return $this->produit_code;
    }

    public function setProduitCode($produit_code)
    {
        $this->produit_code =$produit_code;
    }




// insertion de stock
    public function InsertStock($quantite,$produit_code)
    {
        try{
            $conn = connect();
            $p= $conn->prepare("INSERT INTO stock (Qte,produit_code) VALUES(:q, :p)");
            // $p->bindParam(':s', $code_stock);
            $p->bindParam(':q', $quantite);
            $p->bindParam(':p', $produit_code);
            

        $response =$p->execute();
        return $response;
        }catch(PDOException $e)
        {
            echo $e ->getMessage();
        }

    }

    //Selection de stock
    public function Select()
    {
         try{
            $sql="CALL 		Select_stcok()";
            $conn = connect();
            $p=$conn->prepare($sql);
            $p->execute();
            $result = $p->fetchAll(PDO::FETCH_ASSOC);
    
            return $result;
            }
            catch(PDOException $e)
            {
                echo $e->getMessage();
            }
    }

    // Update stock
    public function Update_Stock($quantite,$produit_code)
    {
        try{
            $conn = connect();
            $p= $conn->prepare("CALL Update_Stock (:q, :p)");
           
            $p->bindParam(':q', $quantite);
            $p->bindParam(':p', $produit_code);
            
            

            $response =$p->execute();
            return $response;
        }catch(PDOException $e)
        {
            echo $e ->getMessage();
        }

    }
// delete stock
    public function DeleteStock($produit_code)
    {
            try{
            $conn = connect();
            $p = $conn->prepare("CALL Delete_Stock(:c)");

            $p->bindParam(':c',$produit_code);
            

            $response = $p->execute();

            return $response;
            
              }
                 catch(PDOException $e)
                 {

                    echo $e->getMessage();

                 }
    }

}


// $t = new stock();

// $code_stock = readline("Entrer le code  ");
// $t->setCodeStock($code_stock);


// $quantite = readline("Entrer la quantite: ");
// $t->setQuantite($quantite);

// $produit_code = readline("Entrer le code du produit: ");
// $t->setProduitCode($produit_code);


// $t->Update_Stock($code_stock,$quantite,$produit_code);

// if ($t);
// echo "modification reussie" ;



// $t = new stock();
// $produit_code = readline("Entrer le code du produit: ");
// $t->setProduitCode($produit_code);


// $t->DeleteStock($produit_code);

// if ($t);
// echo "Suppression reussie" ;


?>