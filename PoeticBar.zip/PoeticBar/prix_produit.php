<?php
include("connexion.php");

class PrixProduit
{    private $code_prix;
     private $produit_code;
     private $prix;

     public function getCodePrix()
     {
         return $this->code_prix;
     }
 
     public function setCodePrix($newCodeP)
     {
         $this->code_prix =$newCodeP;
     }
 


    public function getProduitCode()
    {
        return $this->produit_code;
    }

    public function setProduitCode($newProduitCode)
    {
        $this->produit_code =$newProduitCode;
    }

    public function getPrix()
    {
        return $this->prix;
    }

    public function setPrix($newPrix)
    {
        $this->prix =$newPrix;
    }
// insertion de prix des prodiuts
    public function InsertPrixProduit($produit_code,$prix)
    {
        try{
            $conn = connect();
            $p= $conn->prepare("CALL InsertPrixProduit (:c, :p)");
            
            $p->bindParam(':c', $produit_code);
            $p->bindParam(':p', $prix);

            $response =$p->execute();
            return $response;
        }catch(PDOException $e)
        {
            echo $e ->getMessage();
        }

    }

    // Update de prix des prodiuts
    public function Update_prix_produit($code_prix,$produit_code,$prix)
    {
        try{
            $conn = connect();
            $p= $conn->prepare("CALL Update_prix_produit (:x,:c, :p)");
            $p->bindParam(':x', $code_prix);
            $p->bindParam(':c', $produit_code);
            $p->bindParam(':p', $prix);

            $response =$p->execute();
            return $response;
        }catch(PDOException $e)
        {
            echo $e ->getMessage();
        }

    }

    //Selection de prix produit
    public function SelectPrixProduit()
    {
         try{
            $sql="CALL 	Select_prix_produit()";
            $conn = connect();
            $p=$conn->prepare($sql);
            $p->execute();
            $result = $p->fetchAll(PDO::FETCH_ASSOC);
    
            return $result;
            }
            catch(PDOException $e)
            {
                echo $e->getMessage();
            }
    }
}


// $t = new PrixProduit();
// $code_prix = readline("Entrer le code : ");
// $t->setCodePrix($code_prix);

// $prix = readline("Entrer le prix: ");
// $t->setPrix($prix);

// $produit_code = readline("Entrer le code du produit: ");
// $t->setProduitCode($produit_code);

// $t->Update_prix_produit($code_prix,$prix,$produit_code);

// if ($t);
// echo "modification reussie" ;



?>