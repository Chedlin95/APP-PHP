<?php
include("connexion.php");

$con =connect();
$sql="SELECT * FROM produit";
$exec = $con->query($sql);
$tous =$exec->fetchAll();

?>
<div style="color:blue; font-size:28px; text-align:center">Liste des Produit</div>
<br>


<table class="table">
  <thead>
    <tr>
      <th scope="col">Produit Code</th>
      <th scope="col">Produit Name</th>
      <th scope="col">Type Produit</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($tous as $p){
        echo("
            <tr>
                <td>$p[produit_code]</td>
                <td>$p[produit_name]</td>
                <td>$p[type_produit]</td>
                
                <td><a href='?produit_code=$p[produit_code]'>Modifier</a></td>
                <td><a href='?produit_code=$p[produit_code]' style='color:red;'>Suprimer</a></td>
            </tr>
        ");
    }

    ?>
  </tbody>
</table>

<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item active">
      <a class="page-link" href="?frmProduit" tabindex="-1">Previous</a>

</nav>
