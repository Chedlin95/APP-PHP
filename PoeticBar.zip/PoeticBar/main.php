<?php
session_start();
if(!isset($_SESSION['username']) AND !isset($_SESSION['password'])){
    header("LOCATION:login.php");
}


?>

<!doctype html>
<html lang="pt-br">
<head>

    <meta charset="utf-8"/>
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title>PoeticBar</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>

    <!-- Bootstrap core CSS     -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Animation library for notifications   -->
    <link href="css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet"/>

</head>
<body>

<div class="wrapper">

    <div class="sidebar" data-color="purple" data-image="img/aa.jpg">


        <div class="sidebar-wrapper">
            <div class="logo">
                <img src="img/logo1.jpg" alt="logo" width="210px" heigth="150px">
              
            </div>

            <ul class="nav">
            <li class="active">
                <a href="?Acceuil">
                    <i class="pe-7s-home"></i>
                    <p>Accueil</p>
                </a>
            </li>
            <?php if(($_SESSION['username'])==='Admin'){
                echo('
              
            <li>
                <a href="?users">
                    <i class="pe-7s-user"></i>
                    <p>Utilisateur</p>
                </a>
            </li>
        
            
            <li>
                <a href="?frmProduit_type">
                    <i class="pe-7s-tools"></i>
                    <p>Type Produit</p>
                </a>
            </li>
            <li>
                <a href="?frmProduit">
                    <i class="pe-7s-bandaid"></i>
                    <p>Produits</p>
                </a>
            </li>
            <li>
                <a href="?frmPrix">
                <i class="fa fa-usd" aria-hidden="true"></i>
                    <p>Prix</p>
                </a>
            </li>

            <li>
            <a href="?frmVente">
                <i class="pe-7s-cart"></i>
                <p>Vente</p>
            </a>
        </li>

            <li>
                <a href="?frmStock">
                <i class="pe-7s-graph2"></i>
                <p>Stock</p>
                </a>
            </li>

                ');
               
            }?>
                <?php if(($_SESSION['username'])==='Caissier'){
                    echo('
                        <li>
                        <a href="?frmVente">
                            <i class="pe-7s-cart"></i>
                            <p>Vente</p>
                        </a>
                    </li>
                    ');
                }?>
               

                

               
            </ul>
        </div>
    </div>


    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                            data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                 
                 
                    <nav style="position-relatives; left:10px;" class="navbar navbar-light bg-light"  >
  <form class="form-inline" method="GET">
    <input name="recherche_produit"  class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
    <input type="submit"  name="" class="btn btn-outline-success my-2 my-sm-0"  style="background-color:blue; color:white;" value="Search"/>
  </form>
  
</nav>


                </div>
                <div class="collapse navbar-collapse">

                
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="logout.php">
                                <i class="pe-7s-power">Logout</i>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-left">
                        <li>
                        <div class="form-check" style="color:white;"  >
                            <label class="form-check-label">
                            <i style="margin-left:210px;" class="fa fa-user-circle-o" aria-hidden="true"></i>
                                <input style="margin-top:35px;margin-left:5px;  " class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" >
                                
                                <?php echo($_SESSION['username'].' '.' est connecté');?>
                               
                             
                            </label>
                        </div>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
           <?php
                if(isset($_GET['recherche_produit'])){
                    include("rechere_produit.php");
                }

           ?>

            <?php 
            if(isset($_GET['gestion_vente'])){
                            include("gestion_vente.php");
                        }

                        if(isset($_GET['Aujourdhuit'])){
                            include("gestion_vente.php");
                        }

                        if(isset($_GET['date1']) AND isset($_GET['date2'])){
                            include("gestion_vente.php");
                        }

                if(isset($_GET['users']))
                {
                    include('user.php');
                }

                if(isset($_GET['id']))
                {
                    include('user.php');
                }


            ?>
            
            <?php 
                if(isset($_GET['frmProduit_type']))
                {
                    include('frmProduit_type.php');
                }
            ?>


            <?php 
                if(isset($_GET['frmProduit']))
                {
                    include('frmProduit.php');
                }
            ?>

            <?php 
                if(isset($_GET['frmPrix']))
                {
                    include('frmPrix.php');
                }
            ?>


            <?php 
                if(isset($_GET['frmStock']))
                {
                    include('frmStock.php');
                }
            ?>

<?php 
                if(isset($_GET['frmVente']))
                {
                    include('frmVente.php');
                }

 

                if(isset($_GET['Code_vente'])){
                    include("Modification_vente.php");
                }

                if(isset($_GET['produit_code'])){
                    include("modification_produit.php");
                }

                if(isset($_GET['code_prix'])){
                    include("modification_prix.php");
                }

                if(isset($_GET['type_produit'])){
                    include("modification_type_produit.php");
                }

                if(isset($_GET['code_stock'])){
                    include("modification_stock.php");
                }


                if(isset($_GET['listerProduit'])){
                    include("listerProduit.php");
                }
                if(isset($_GET['listerPrix'])){
                    include("listerPrix.php");
                }
                if(isset($_GET['listerStock'])){
                    include("listerStock.php");
                }

                if(isset($_GET['listerTypeProduit'])){
                    include("listerTypeProduit.php");
                }

                
                if(isset($_GET['index'])){
                    include("index.php");
                }


            ?>

              <?php
              if(isset($_GET['Acceuil'])){ ?>
                <div style="text-align:center; background-color:gray;  front-size:28px;  color:white;">
                    <p style="font-size:28px;">  <marquee behavior="" direction="left">Bienvenue à Minu PoeticBar. Voici  Quelques Produits !!!</marquee> </p>
                </div>
                <br>
              <?php }  ?>
<?php 
                        if(isset($_GET['Acceuil'])){
                            echo("
                            <div style='width:auto;height:240px;'>
                            <div class='col-sm-3'>
                            <div class='box box-solid'>
                                <div class='box-body prod-body'>
                                <a href='?frmProduit_type'><img src='images/PRESTIGE.jpg' width='100%' height='230px' class='thumbnail'></a>
                                    
                                </div>
                                <div class='box-footer'>
                                    <b></b>
                                </div>
                            </div>
                        </div>

                        <div class='col-sm-3'>
                        <div class='box box-solid'>
                            <div class='box-body prod-body'>
                            <a href='?frmProduit_type'><img src='images/image.jpg' width='100%' height='230px' class='thumbnail'></a>
                            </div>
                            <div class='box-footer'>
                                <b></b>
                            </div>
                        </div>
                    </div>

                    <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?frmProduit_type'><img src='images/Corn-Flakes-Hyde.jpg' width='100%' height='230px' class='thumbnail'></a>
                          
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?frmProduit_type'><img src='images/alcoolise.jpg' width='100%' height='230px' class='thumbnail'></a>
                            
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                </div>


                <div style='width:auto;height:250px;'>
                            <div class='col-sm-3'>
                            <div class='box box-solid'>
                                <div class='box-body prod-body'>
                                <a href='?frmProduit_type'> <img src='images/parfum.jpg' width='100%' height='230px' class='thumbnail'></a>
                                    
                                </div>
                                <div class='box-footer'>
                                    <b></b>
                                </div>
                            </div>
                        </div>

                        <div class='col-sm-3'>
                        <div class='box box-solid'>
                            <div class='box-body prod-body'>
                            <a href='?frmProduit_type'> <img src='images/champoo.jpg' width='100%' height='230px' class='thumbnail'></a>
                                
                            </div>
                            <div class='box-footer'>
                                <b></b>
                            </div>
                        </div>
                    </div>

                    <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?frmProduit_type'><img src='images/papier.png' width='100%' height='230px' class='thumbnail'></a>
                           
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                <div class='col-sm-3'>
                    <div class='box box-solid'>
                        <div class='box-body prod-body'>
                        <a href='?frmProduit_type'><img src='images/creme.jpg' width='100%' height='230px' class='thumbnail'></a>
    
                        </div>
                        <div class='box-footer'>
                            <b></b>
                        </div>
                    </div>
                </div>
                </div>


                <div style='width:auto;height:250px;'>
                <div class='col-sm-3'>
                <div class='box box-solid'>
                    <div class='box-body prod-body'>
                    <a href='?frmProduit_type'> <img src='images/pc.jpg' width='100%' height='230px' class='thumbnail'></a>
                        
                    </div>
                    <div class='box-footer'>
                        <b></b>
                    </div>
                </div>
            </div>

            <div class='col-sm-3'>
            <div class='box box-solid'>
                <div class='box-body prod-body'>
                <a href='?frmProduit_type'> <img src='images/phone.jpg' width='100%' height='230px' class='thumbnail'></a>
                    
                </div>
                <div class='box-footer'>
                    <b></b>
                </div>
            </div>
        </div>

        <div class='col-sm-3'>
        <div class='box box-solid'>
            <div class='box-body prod-body'>
            <a href='?frmProduit_type'><img src='images/radio.jpg' width='100%' height='230px' class='thumbnail'></a>
               
            </div>
            <div class='box-footer'>
                <b></b>
            </div>
        </div>
    </div>
    <div class='col-sm-3'>
        <div class='box box-solid'>
            <div class='box-body prod-body'>
            <a href='?frmProduit_type'><img src='images/tv.jpg' width='100%' height='230px' class='thumbnail'></a>

            </div>
            <div class='box-footer'>
                <b></b>
            </div>
        </div>
    </div>
    </div>
                            
                
                
                ");

                        }
                    ?>
            </div>
        </div>

        
        <footer class="footer"  style="background-color:gray";>
            <div class="container-fluid">
                <p class="copyright pull-right"  style="color:white">
                    &copy;
                    <script>document.write(new Date().getFullYear())</script>
                    Team 4 Sfotware
                </p>
            </div>
        </footer>
    </div>
</div>
</body>

<script src="js/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="js/demo.js"></script>
<script src="assets/js/demo.js"></script>
<script type="text/javascript">

    $(document).ready(function () {
        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

        demo.showNotification();

    });
</script>


</html>
