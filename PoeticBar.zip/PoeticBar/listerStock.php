
<?php
include("connexion.php");

$con =connect();
$sql="SELECT * FROM stock";
$exec = $con->query($sql);
$tous =$exec->fetchAll();

?>
<div style="color:blue; font-size:28px; text-align:center">Liste de Stock</div>
<br>


<table class="table">
  <thead>
    <tr>
      <th scope="col">Code Stock</th>
      <th scope="col">Code Produit</th>
      <th scope="col">Quantité</th>
     
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($tous as $p){
        echo("
            <tr>
                <td>$p[code_stock]</td>
                <td>$p[produit_code]</td>
                <td>$p[Qte]</td>
                
                
                <td><a href='?code_stock=$p[code_stock]'>Modifier</a></td>
                <td><a href='?code_stock=$p[code_stock]' style='color:red;'>Suprimer</a></td>
            </tr>
        ");
    }

    ?>
  </tbody>
</table>

<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item active">
      <a class="page-link" href="?frmStock" tabindex="-1">Previous</a>

</nav>