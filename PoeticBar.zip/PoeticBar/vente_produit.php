<?php 
include("connexion.php");

 class vente
 {
     private $code_vente;
     private $produit_code;
     private $Qte;
     private $totale;
     private $date_vente;

     public function getCodeVente()
     {
         return $this->code_vente;
     }

     public function setCodeVente($newCodeVente)
     {
         $this->code_vente =$newCodeVente;
     }

      public function getProduitCode()
     {
         return $this->produit_code;
     }

     public function setProduitCode($newProduitCode)
     {
         $this->produit_code=$newProduitCode;
     }

     public function getQte()
     {
         return $this->Qte;
     }

     public function setQte($newQte)
     {
         $this->Qte=$newQte;
     }

     public function getTotale()
     {
         return $this->totale;
     }

     public function setTotale($newTotale)
     {
         $this->totale=$newTotale;
     }

     public function getDateVente()
     {
         return $this->date_vente;
     }

     public function setDateVente($newDateVente)
     {
         $this->date_vente=$newDateVente;
     }


// insertion de vente

    public function InsertVenteProduit($produit_code,$Qte,$totale,$date_vente)

    {
        try{
            $conn = connect();
            $p= $conn->prepare("CALL InsertVenteProduit  (:p, :q, :t, :d)");
        
            $p->bindParam(':p', $produit_code);
            $p->bindParam(':q', $Qte);
            $p->bindParam(':t', $totale);
            $p->bindParam(':d', $date_vente);
            
            $response =$p->execute();
            return $response;
        }catch(PDOException $e)
        {
            echo $e ->getMessage();
        }

    }

    
// Udate de vente

    public function Update_vente($produit_code,$Qte,$totale,$date_vente,$code_vente)

    {
        try{
            $conn = connect();
            $p= $conn->prepare("CALL Update_vente (:c, :p, :q, :t, :d)");
    
            $p->bindParam(':p', $produit_code);
            $p->bindParam(':q', $Qte);
            $p->bindParam(':t', $totale);
            $p->bindParam(':d', $date_vente);
            $p->bindParam(':c', $code_vente);
            
            $response =$p->execute();
            return $response;
        }catch(PDOException $e)
        {
            echo $e ->getMessage();
        }

    }

    // Delete vente
    
    public function DeleteVente($code_vente)

    {
        try{
            $conn = connect();
            $p= $conn->prepare("CALL Delete_vente (:c)");
        
            $p->bindParam(':c', $code_vente);
            
            $response =$p->execute();
            return $response;
        }catch(PDOException $e)
        {
            echo $e ->getMessage();
        }

    }


}



// $v = new vente();
// $code_vente = readline("Entrer le code vente: ");
// $v->setCodeVente($code_vente);
// $produit_code = readline("Entrer le code du produit: ");
// $v->setProduitCode($produit_code);
// $Qte = readline("Entrer la quantite: ");
// $v->setQte($Qte);
// $totale = readline("Entrer la totale: ");
// $v->setTotale($totale);
// $date_vente = readline("Entrer la date: ");
// $v->setDateVente($date_vente);
// $v->UpdateVenteProduit($code_vente,$produit_code,$Qte,$totale,$date_vente);

// if ($v);
// echo "modification reussie" ;

// $v = new vente();
// $code_vente = readline("Entrer le code de la vente: ");
// $v->setCodeVente($code_vente);


// $v->DeleteVente($code_vente);

// if ($v);
// echo "Suppression reussie" ;
?>