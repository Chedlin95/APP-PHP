<?php
 require_once('prix_produit.php');
 $code_prix="";
 $produit_code ="";
 $prix = "";
 
if(isset($_GET['code_prix'])){

    $code_prix= $_GET['code_prix'];
    $con= connect();
    $sql ="SELECT * FROM prix WHERE code_prix='$code_prix'";
    $result =$con->query($sql);
    $req = $result->fetchAll();

    foreach($req as $p){
        $produit_code = $p['produit_code'];
        $prix = $p['prix_p'];
       
    
    }

}


?>
<?php
          
         

          if(isset($_POST['Update_prix_produit']))
          {
            $p= new PrixProduit();
            $p->setCodePrix($_POST['code_prix']);
            $p->setProduitCode($_POST['produit_code']);
            $p->setPrix($_POST['prix_p']);
            

                  if( 
                    $p->Update_prix_produit(
                    $p->getCodePrix(),
                    $p->getPrix(),
                    $p->getProduitCode()
                   
                   
                  ))

                  {
                  echo('                         
                              <span style= "background-color:blue " class="alert alert-success col-sm-4" role="alert">
                                  Modification avec succes!
                              </span>
                      ');
                  }
            }
    ?>
<br><br><br>

<form action="" method="POST">
     <center><h4 style="text-shadow:1px 2px 1px blue;color:#383f39;margin-top:-20px;text-aligne:center;">Modification de Prix</h4></center>
     <div class="form-group">
        <label for="exampleFormControlInput1"> Code Prix</label>
        <input type="text" readonly="true" value="<?php if(isset($code_prix)){echo($code_prix);} ?>" name="code_prix" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    

    <div class="form-group">
        <label for="exampleFormControlInput1"> produit code</label>
        <input type="text" readonly="true" value="<?php if(isset($produit_code)){echo($produit_code);} ?>" name="produit_code" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    
    <div class="form-group">
        <label for="exampleFormControlInput1">Prix produits</label>
        <input type="text" value="<?php if(isset($prix)){echo($prix);} ?>" name="prix_p" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>

   
    <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Valider" name="Update_prix_produit">
        <!-- <button style="color:white;border:none;width:300px;float:right;margin-right:20px;top:-10px;background:#4c4c4c;" type="reset" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Go to check for Update</button>
        <button style="color:white;border:none;width:150px;float:right;margin-right:20px;top:-10px;background:green;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i> View satistics</button>
        <button style="color:white;border:none;width:150px;float:left;margin-right:20px;top:-10px;background:green;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-paper-plane" aria-hidden="true"></i> Enregistrer</button> -->
        <?php if(isset($v1)){echo('<button style="color:white;border:none;width:200px;float:left;margin-right:20px;top:-10px;background:#d1931b;" type="submit" name="Update_prix_produit" class="btn btn-warning"><i class="fa fa-paper-plane" aria-hidden="true"></i> Update Succesfuly</button>');}?>
    </div>  

    

</form>


<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item active">
      <a class="page-link" href="?listerPrix" tabindex="-1">Previous</a>
    <!-- </li>
    <li class="page-item"><a class="page-link" href="?gestion_vente"> <span class="sr-only">(current)</span>Gestion de vente</a></li>
     -->
  </ul>
</nav>