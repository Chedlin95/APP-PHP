<?php

// if(!isset($_SESSION['username'])=='Administrateur'){
//   header("LOCATION:login.php");
// }
include("users.class.php");
  $data = User::selection_all_user();
  $data = $data->fetchAll();

?>

<?php
if(isset($_GET['id'])){
    $id=$_GET['id'];
    $execution = User::select_by_id($id);

    foreach($execution as $exec){
        $id = $exec['id'];
        $username = $exec['username'];
        $role = $exec['role'];
        $password = $exec['password'];
    }
}


// insertion utilisateur//

            if(isset($_POST['save_utilisateur'])){
                $username=$_POST['username'];
                $role=$_POST['role'];
                $password = $_POST['password'];

                $utisateur = new User($username,$role,$password);

                $username = $utisateur->getUsername();
                $password = $utisateur->getPassword();
                $role = $utisateur->getRole();

                $resultat = User::insertion($username,$role,$password);

            }
// update user

if(isset($_POST['modifier_user'])){
    $username=$_POST['username'];
    $role=$_POST['role'];
    $password = $_POST['password'];

    $utisateur = new User($username,$role,$password);

    $username = $utisateur->getUsername();
    $password = $utisateur->getRole();
    $password = $utisateur->getPassword();
    

    $resultat1 = User::modifier($username,$role,$password,$_GET['id']);

}
////////delete///

if(isset($_POST['suprimer_user'])){
    $id=$_GET['id'];
    $resultat2 = User::delete_user($id);

}




?>
<div class="card" style="float:right;margin-right:100px;width:900px;box-shadow:1px 1px 5px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
    <tr style="background:#5c5a57;">
      <th style="color:white;font-weight:bolder;" scope="col">Username </th>
      <th style="color:white;font-weight:bolder;" scope="col">Password</th>
      <th style="color:white;font-weight:bolder;" scope="col">Role </th>
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($data as $rs){
      echo("
          <tr>
              <td>$rs[username]</td>
              <td>$rs[password]</td>
              <td>$rs[role]</td>
              <td><a href='main.php?id=$rs[id]'><button type='submit' name='Addproduit' style='background:green;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-edit' aria-hidden='true'></i>Edit</button></a><td>
              <td><a href='main.php?id=$rs[id]'><button type='submit' name='Delete' style='background:red;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-trash' aria-hidden='true'></i> Delete</button></a><td>
              <td><a href='?users'><button type='submit' name='Delete' style='background:green;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-user' aria-hidden='true'></i> Ajouter utilisateur</button></a><td>
             
              
          </tr>
      ");
    } ?>
  </tbody>
</table>

  </div>
</div>
<br><br><br><br><br><br><br><br><br>

<form action="" method="POST">
    
    <div class="form-group">
        <label for="exampleFormControlInput1">Username</label>
        <input type="text" value="<?php if(isset($_GET['id'])){if(isset($username)){echo($username);}} ?>" name="username" class="form-control" id="exampleFormControlInput1" placeholder="" required autocomplete="off">
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Role</label>
        <input value="<?php if(isset($_GET['id'])){if(isset($role)){echo($role);}} ?>" type="text" name="role" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>

    <div class="form-group">
        <label for="exampleFormControlInput1">Password</label>
        <input value="<?php if(isset($_GET['id'])){if(isset($password)){echo($password);}} ?>" type="password" name="password" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
   
    <div class="form-group">
    <?php if(isset($_GET['id'])){echo('<button style="color:white;border:none;width:120px;float:right;margin-left:20px;top:-10px;background:red;" type="submit" name="suprimer_user" class="btn btn-success"><i class="fa fa-trash" aria-hidden="true"></i>Suprimer</button>');}?>
        <?php if(isset($_GET['id'])){echo('<button style="color:white;border:none;width:120px;float:right;margin-left:20px;top:-10px;background:#4c4c4c;" type="submit" name="modifier_user" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i><i class="fa fa-user" aria-hidden="true"></i> Modifier</button>');}?>
        <?php if(isset($_GET['users'])){echo('<button style="color:white;border:none;width:120px;float:right;margin-right:20px;top:-10px;background:#4c4c4c;" type="submit" name="save_utilisateur" class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> Ajouter</button>');}?>
        <?php if(isset($_GET['users']) AND isset($resultat)){echo('<button style="color:white;border:none;width:300px;float:left;margin-right:20px;top:-10px;background:#764600;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> Add Successfuly...</button>');} ?>
        <?php if(isset($_GET['id']) AND isset($resultat1)){echo('<button style="color:white;border:none;width:300px;float:left;margin-right:20px;top:-10px;background:#764600;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> Update Successfuly...</button>');} ?>
        <?php if(isset($_GET['id']) AND isset($resultat2)){echo('<button style="color:white;border:none;width:300px;float:left;margin-right:20px;top:-10px;background:#764600;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> delete Successfuly...</button>');} ?>
    </div>                            
</form>