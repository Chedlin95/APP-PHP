<?php
include("connexion.php");

$con =connect();
$sql="SELECT * FROM prix";
$exec = $con->query($sql);
$tous =$exec->fetchAll();

?>
<div style="color:blue; font-size:28px; text-align:center">Liste des Prix</div>
<br>


<table class="table">
  <thead>
    <tr>
      <th scope="col">Code</th>
      <th scope="col">Code Produit </th>
      <th scope="col">Prix Produit</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($tous as $p){
        echo("
            <tr>
                <td>$p[code_prix]</td>
                <td>$p[produit_code]</td>
                <td>$p[prix_p]</td>
                
                <td><a href='?code_prix=$p[code_prix]'>Modifier</a></td>
                <td><a href='?code_prix=$p[code_prix]' style='color:red;'>Suprimer</a></td>
            </tr>
        ");
    }

    ?>
  </tbody>
</table>

<nav aria-label="...">
  <ul class="pagination">
    <li class="page-item active">
      <a class="page-link" href="?frmPrix" tabindex="-1">Previous</a>

</nav>