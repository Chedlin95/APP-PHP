<form action="" method="POST">
     <center><h4 style="text-shadow:1px 2px 1px blue;color:#383f39;margin-top:-20px;text-aligne:center;">Enregistrement Prix</h4></center>
    
    <div class="form-group">
        <label for="exampleFormControlInput1"> Produit code</label>
        <input type="text" value="" name="produit_code" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>
    
    <div class="form-group">
        <label for="exampleFormControlInput1"> Prix</label>
        <input type="number" value="" name="prix" class="form-control" id="exampleFormControlInput1" required autocomplete="off" placeholder="">
    </div>

    <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Valider" name="save_prix">
        <!-- <button style="color:white;border:none;width:300px;float:right;margin-right:20px;top:-10px;background:#4c4c4c;" type="reset" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Go to check for Update</button>
        <button style="color:white;border:none;width:150px;float:right;margin-right:20px;top:-10px;background:green;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i> View satistics</button>
        <button style="color:white;border:none;width:150px;float:left;margin-right:20px;top:-10px;background:green;" type="submit" name="update_produit" class="btn btn-success"><i class="fa fa-paper-plane" aria-hidden="true"></i> Enregistrer</button> -->
        <?php if(isset($v1)){echo('<button style="color:white;border:none;width:200px;float:left;margin-right:20px;top:-10px;background:#d1931b;" type="submit" name="update_produit" class="btn btn-warning"><i class="fa fa-paper-plane" aria-hidden="true"></i> Update Succesfuly</button>');}?>
    </div>  

    <?php
          
          require_once('prix_produit.php');

          if(isset($_POST['save_prix']))
          {
            $pro= new PrixProduit();
            $pro->setProduitCode($_POST['produit_code']);
              $pro->setPrix($_POST['prix']);
            

                  if( 
                    $pro->InsertPrixProduit(
                    $pro->getProduitCode(),
                    $pro->getPrix() 
                  ))

                  {
                  echo('                         
                              <span style= "background-color:blue " class="alert alert-success col-sm-4" role="alert">
                                   Prix Enregistrer avec succes!
                              </span>
                      ');
                  }
            }
    ?>

</form>
<nav aria-label="...">
  <ul class="pagination">
   
    
    <li class="page-item active ">
      <a class="page-link" href="?listerPrix">Liste de Prix </a>
    </li>
  </ul>
</nav>