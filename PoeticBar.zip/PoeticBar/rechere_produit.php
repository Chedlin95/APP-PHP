<?php
  include("produit.class.php");
  if(isset($_GET['recherche_produit'])){
    $produit_code =$_GET['recherche_produit'];
    $execution = Produit::recherche($produit_code);
    $data = $execution->fetchAll();
  }
  

?>

<?php


?>
<div class="card" style="border:3px solid #5c5a57;margin-right:-22px;float:right;width:1100px;box-shadow:1px 1px 5px green;">
  <div class="card-body">
  <table class="table">
  <thead class="thead-dark">
    <tr style="background:#5c5a57;color:blue">
      <th style="color:white;font-weight:bolder;" scope="col">produit code </th>
      <th style="color:white;font-weight:bolder;" scope="col">Name</th>
      <th style="color:white;font-weight:bolder;" scope="col">Type produit</th>
      <th style="color:white;font-weight:bolder;" scope="col">Type name</th>
      
    </tr>
  </thead>
  <tbody>
  <?php
    foreach($data as $rs){
      echo("
          <tr>
              <td>$rs[produit_code]</td>
              <td>$rs[produit_name]</td>
              <td>$rs[type_produit]</td>
              <td>$rs[type_name]</td>
              <td><a href='main.php?produit_code=$rs[produit_code]'><button type='submit' name='Addproduit' style='background:blue;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-edit' aria-hidden='true'></i>Modifier</button></a><td>
             
             
              
          </tr>
      ");
    } //<td><a href='main.php?produit_code=$rs[produit_code]'><button type='submit' name='Delete' style='background:red;color:white;border:none;width:100%;' class='btn btn-success'><i class='fa fa-trash' aria-hidden='true'></i> Suprimer</button></a><td>?>
  </tbody>
</table>

  </div>
</div>