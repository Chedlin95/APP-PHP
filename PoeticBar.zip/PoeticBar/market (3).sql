-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2020 at 09:45 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `market`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Delete_Produit` (IN `codeP` VARCHAR(50))  NO SQL
DELETE FROM `produit` WHERE codeP=produit_code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Delete_Stock` (IN `code` INT(50))  NO SQL
DELETE FROM `stock` WHERE code=produit_code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Delete_type_produit` (IN `type` VARCHAR(50))  NO SQL
DELETE FROM `produit_type` WHERE type=Type_produit$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Delete_vente` (IN `code` VARCHAR(50))  NO SQL
DELETE FROM `vente_produit` WHERE code=code_vente$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPrixProduit` (IN `code_produit` VARCHAR(50), IN `prixP` FLOAT(11))  NO SQL
INSERT INTO `prix`(`produit_code`, `prix_p`)VALUES (code_produit,prixP)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertProduit` (IN `codeP` VARCHAR(50), IN `name` VARCHAR(50), IN `type` VARCHAR(50))  NO SQL
INSERT INTO `produit`(`produit_code`, `produit_name`, `Type_produit`) VALUES (codeP,name,type)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertProduitType` (IN `type_produit` VARCHAR(50), IN `type_name` VARCHAR(50))  NO SQL
INSERT INTO `produit_type`(`Type_produit`, `type_name`) VALUES (type_produit,type_name)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertStock` (IN `code` VARCHAR(11), IN `quantite` INT(11), IN `p_code` VARCHAR(11))  NO SQL
INSERT INTO `stock`(`code_stock`, `Qte`, `produit_code`) VALUES (code,quantite,p_code)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertVenteProduit` (IN `pro_code` VARCHAR(50), IN `qte` INT(11), IN `totale` FLOAT, IN `date_v` DATE)  NO SQL
INSERT INTO `vente_produit`( `produit_code`, `Qte`, `Total`, `Date_vente`) VALUES (pro_code,qte,totale,date_v)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectProduit` ()  NO SQL
SELECT * FROM `produit` WHERE 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_prix_produit` ()  NO SQL
SELECT * FROM `prix` WHERE 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_prix_produit_par_code` (IN `code` VARCHAR(50))  NO SQL
SELECT * FROM `prix_produit` WHERE `produit_code`=code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_Produit` ()  NO SQL
SELECT `produit_code`, `produit_name`, `type_produit` FROM `produit` WHERE 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_produit_par_code` (IN `code` VARCHAR(50))  NO SQL
SELECT * FROM `produits` WHERE `produit_code`=code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_produit_par_nom` (IN `name` VARCHAR(50))  NO SQL
SELECT * FROM `produits` WHERE `produit_name`=name$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_produit_par_prix` (IN `prix_pro` FLOAT)  NO SQL
SELECT * FROM `prix_produit` WHERE `prix`=prix_pro$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_produit_par_type` (IN `type` VARCHAR(50))  NO SQL
SELECT * FROM `produits` WHERE `Type_produit`=type$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_Produit_type_par_type` (IN `type` VARCHAR(50))  NO SQL
SELECT * FROM `produit_type` WHERE `Type_produit`=type$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_stcok` ()  NO SQL
SELECT * FROM `stock` WHERE 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_Stock_par_quantite` (IN `qte` INT(11))  NO SQL
SELECT * FROM `stock` WHERE `Qte`=qte$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_stock_produit_code` ()  NO SQL
SELECT * FROM `stock` WHERE `produit_code` = code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_TypeProduit_par_Type_name` (IN `name` VARCHAR(50))  NO SQL
SELECT * FROM `produit_type` WHERE `type_name`=name$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_vente_par_code_Produit` (IN `code` VARCHAR(50))  NO SQL
SELECT * FROM `vente_produit` WHERE `produit_code`=code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_vente_par_date` (IN `date` DATE)  NO SQL
SELECT * FROM `vente_produit` WHERE `Date_vente`=date$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_vente_par_quantite` (IN `quantite` INT)  NO SQL
SELECT * FROM `vente_produit` WHERE `Qte`=quantite$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_vente_par_totale` (IN `total` FLOAT)  NO SQL
SELECT * FROM `vente_produit` WHERE `Total`=total$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_vente_produit` ()  NO SQL
SELECT * FROM `vente_produit` WHERE 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_prix_produit` (IN `code_pr` VARCHAR(50), IN `prix_pro` FLOAT(11), IN `code` VARCHAR(11))  NO SQL
UPDATE `prix` SET `prix_p`=prix_pro,`produit_code`=code WHERE `code_prix`=code_pr$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Produit` (IN `code` VARCHAR(50), IN `name` VARCHAR(50), IN `type` VARCHAR(50))  NO SQL
UPDATE `produit` SET `produit_name`=name,`Type_produit`=type WHERE `produit_code`=code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_produit_type` (IN `type` VARCHAR(50), IN `name` VARCHAR(50))  NO SQL
UPDATE `produit_type` SET `type_name`=name WHERE `Type_produit`=type$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Stock` (IN `code` VARCHAR(50), IN `quantite` INT(50))  NO SQL
UPDATE `stock` SET `Qte`=quantite WHERE `code_stock`=code$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_vente` (IN `code_v` VARCHAR(50), IN `code` VARCHAR(50), IN `quantite` INT(11), IN `total` FLOAT, IN `date_` DATE)  NO SQL
UPDATE `vente_produit` SET `produit_code`=code,`Qte`=quantite,`Total`=total,`Date_vente`=date_ WHERE `Code_vente`=code_v$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `prix`
--

CREATE TABLE `prix` (
  `code_prix` int(11) NOT NULL,
  `prix_p` float NOT NULL,
  `produit_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prix`
--

INSERT INTO `prix` (`code_prix`, `prix_p`, `produit_code`) VALUES
(1, 500, '001'),
(2, 5, '002'),
(3, 12, '003'),
(4, 15, '004'),
(5, 6, '005'),
(6, 5, '006'),
(7, 4, '007');

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

CREATE TABLE `produit` (
  `produit_code` varchar(50) NOT NULL,
  `produit_name` varchar(50) NOT NULL,
  `type_produit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `produit`
--

INSERT INTO `produit` (`produit_code`, `produit_name`, `type_produit`) VALUES
('001', 'Laptop HP', 'Electronique'),
('002', 'Papier Cameo', 'HygiÃ©nique'),
('003', 'Corn flaxe Hyde Park', 'Alimentaire'),
('004', 'Creme Caro white', 'Cosmetique'),
('005', 'Biere', 'Boisson'),
('006', 'Biere Kinanm', 'Boisson'),
('007', 'Famosa', 'Boisson');

-- --------------------------------------------------------

--
-- Table structure for table `produit_type`
--

CREATE TABLE `produit_type` (
  `type_produit` varchar(50) NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `produit_type`
--

INSERT INTO `produit_type` (`type_produit`, `type_name`) VALUES
('Alimentaire', 'Corn flaxes'),
('Boisson', 'Gazeuse /AlcoolisÃ©e'),
('Cosmetique', 'CrÃ¨me peau'),
('Electronique', 'Ordinateur Portable'),
('HygiÃ©nique', 'Papier');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `code_stock` int(11) NOT NULL,
  `Qte` int(11) NOT NULL,
  `produit_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`code_stock`, `Qte`, `produit_code`) VALUES
(1, 500, '001'),
(2, 1200, '002'),
(3, 3000, '003'),
(4, 800, '004'),
(5, 405, '005'),
(6, 1500, '006');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `role`, `password`) VALUES
(1, 'Admin', 'ADM', 'Admin'),
(4, 'Caissier', 'Caissier', 'Caissier');

-- --------------------------------------------------------

--
-- Table structure for table `vente_produit`
--

CREATE TABLE `vente_produit` (
  `Code_vente` int(11) NOT NULL,
  `Qte` int(11) NOT NULL,
  `Total` float NOT NULL,
  `Date_vente` date NOT NULL,
  `produit_code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vente_produit`
--

INSERT INTO `vente_produit` (`Code_vente`, `Qte`, `Total`, `Date_vente`, `produit_code`) VALUES
(1, 1, 500, '2020-07-16', '001'),
(2, 4, 20, '2020-07-15', '002'),
(3, 5, 60, '2020-07-11', '003'),
(4, 2, 30, '2020-07-10', '004'),
(5, 5, 30, '2020-07-09', '005'),
(6, 3, 15, '2020-07-09', '006'),
(7, 10, 40, '2020-07-16', '007');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prix`
--
ALTER TABLE `prix`
  ADD PRIMARY KEY (`code_prix`),
  ADD KEY `PRIX_PRODUIT_FK` (`produit_code`);

--
-- Indexes for table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`produit_code`),
  ADD KEY `PRODUIT_PRODUIT_TYPE_FK` (`type_produit`);

--
-- Indexes for table `produit_type`
--
ALTER TABLE `produit_type`
  ADD PRIMARY KEY (`type_produit`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`code_stock`),
  ADD KEY `STOCK_PRODUIT_FK` (`produit_code`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vente_produit`
--
ALTER TABLE `vente_produit`
  ADD PRIMARY KEY (`Code_vente`),
  ADD KEY `VENTE_PRODUIT_PRODUIT_FK` (`produit_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prix`
--
ALTER TABLE `prix`
  MODIFY `code_prix` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `code_stock` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vente_produit`
--
ALTER TABLE `vente_produit`
  MODIFY `Code_vente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `prix`
--
ALTER TABLE `prix`
  ADD CONSTRAINT `PRIX_PRODUIT_FK` FOREIGN KEY (`produit_code`) REFERENCES `produit` (`produit_code`);

--
-- Constraints for table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `PRODUIT_PRODUIT_TYPE_FK` FOREIGN KEY (`type_produit`) REFERENCES `produit_type` (`type_produit`);

--
-- Constraints for table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `STOCK_PRODUIT_FK` FOREIGN KEY (`produit_code`) REFERENCES `produit` (`produit_code`);

--
-- Constraints for table `vente_produit`
--
ALTER TABLE `vente_produit`
  ADD CONSTRAINT `VENTE_PRODUIT_PRODUIT_FK` FOREIGN KEY (`produit_code`) REFERENCES `produit` (`produit_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
