<?php

    function connect()
    {
      $dns= 'mysql:host=localhost; dbname=market'; 
      $user= 'root';
      $pass='';

      $conn= new PDO($dns,$user,$pass);

      return $conn;
    }
?>